1.Calling Python from MATLAB: "https://ww2.mathworks.cn/help/matlab/call-python-libraries.html?s_tid=CRUX_lftnav".

2.run "main.m" by Matlab.