function [r1, r2] = gnR1R2(NP1, NP2)
% choose the mutation index randly
% temp = floor(rand * (popsize - 1)) + 1
% choose a number in [1,popsize]

popsize= NP1;
r1 = zeros(1, popsize);
r2 = zeros(1, popsize);

for i = 1 : popsize

    sequence = 1 : NP1;
    sequence(i) = [];
    temp = floor(rand * (NP1 - 1)) + 1;
    r1(i) = sequence(temp);

end

for i = 1 : popsize
    sequence = 1 : NP2;
    for p=1:1000000
        temp = floor(rand * NP2) + 1;
        r2(i) = sequence(temp);
        if (r2(i)~=sequence(i))&&(r2(i)~=sequence(r1(i)))
            break;
        end
    end
end
