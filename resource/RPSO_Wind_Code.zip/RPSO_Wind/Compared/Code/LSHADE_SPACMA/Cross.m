function newIndividuals = Cross(individual1, individual2)
    %function that crosses the genes of two individuals with a random
    %probability at a random cross over point
    
    nGenes = size(individual1,2); 
    crossoverPoint = 1 + fix(rand*(nGenes-1));
%     individual1 = unique(individual1);
%     individual2 = unique(individual2);
    newIndividuals = zeros(2,nGenes);
%     if cross==1
%         j_ind = randi(nGenes,1);
%         if (j <= crossoverPoint)
%             if individual1(j) < individual2(j)
%                 newIndividuals(1,j) = individual1(j);
%                 newIndividuals(2,j) = individual2(j);
%             else
% 
%             end
%         end
%     end
%     newIndividuals(1,1:crossoverPoint) = individual1(1:crossoverPoint);
%         newIndividuals(2,1:crossoverPoint) = individual2(1:crossoverPoint);
% 
%         newIndividuals(1,crossoverPoint+1:end) = individual1(crossoverPoint+1:end);
%         newIndividuals(2,crossoverPoint+1:end) = individual2(crossoverPoint+1:end);
%     if individual1(crossoverPoint) < individual2(crossoverPoint)
%         newIndividuals(1,1:crossoverPoint) = individual1(1:crossoverPoint);
%         newIndividuals(2,1:crossoverPoint) = individual2(1:crossoverPoint);
% 
%         newIndividuals(1,crossoverPoint+1:end) = individual1(crossoverPoint+1:end);
%         newIndividuals(2,crossoverPoint+1:end) = individual2(crossoverPoint+1:end);
%     else
%         individual1(crossoverPoint)
%     end

    for j = 1:nGenes
        if (j <= crossoverPoint)
                newIndividuals(1,j) = individual1(j);
                newIndividuals(2,j) = individual2(j);
        else
            newIndividuals(1,j) = individual2(j);
            newIndividuals(2,j) = individual1(j);
        end
    end
    temp_newIndividual1 = unique(newIndividuals(1,:));
    temp_newIndividual2 = unique(newIndividuals(2,:));
%     fprintf('%d %d\n',individual1(crossoverPoint) , individual2(crossoverPoint+1))
%     if individual1(crossoverPoint) > individual2(crossoverPoint+1)
%         ind = randi([individual2(crossoverPoint), individual1(crossoverPoint)],1,nGenes-size(temp_newIndividual1,2));
% %         ind2 = randi([individual2(crossoverPoint), individual1(crossoverPoint)],1,nGenes-size(temp_newIndividual2,2));
%         temp_newIndividual1 = [temp_newIndividual1,ind];
% %         temp_newIndividual2 = [temp_newIndividual2,ind2];
%     end
    while size(temp_newIndividual2,2) < nGenes
        ind = randi(144,1);
%         disp(ind)
        while sum(temp_newIndividual2==ind)==0
            temp_newIndividual2 = [temp_newIndividual2,ind];
            temp_newIndividual2 = unique(temp_newIndividual2);
        end
%         fprintf('%d %d\n',size(temp_newIndividual1,2) , size(temp_newIndividual2,2))
    end

    while size(temp_newIndividual1,2) < nGenes
        ind = randi(144,1);
%         disp(ind)
        while sum(temp_newIndividual1==ind)==0
            temp_newIndividual1 = [temp_newIndividual1,ind];
            temp_newIndividual1 = unique(temp_newIndividual1);
        end
    end
        
%     fprintf('%d %d\n',size(unique(temp_newIndividual1),2) , size(unique(temp_newIndividual2),2))
%     size(unique(temp_newIndividual1),2)
%     size(unique(temp_newIndividual2),2)
    newIndividuals(1,:) = temp_newIndividual1;
    newIndividuals(2,:) = temp_newIndividual2;

    

end