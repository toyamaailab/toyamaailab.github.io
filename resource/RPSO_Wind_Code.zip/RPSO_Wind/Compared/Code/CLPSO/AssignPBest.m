function [pBestSelected, ai] = AssignPBest(popuSize, D, ai, pBestFit, pBestSelected, m)
for i = 1:popuSize
    Pc = 0.05 + 0.45 * (exp(10 * (i - 1) / (popuSize - 1)) -1) / (exp(10) - 1);
    ai(i,:)=zeros(1,D);
    pBestSelected(i,:)=i.*ones(1,D);
    ar=randperm(D);
    ai(i,ar(1:m(i)))=1;
    fi1=ceil(popuSize*rand(1,D));
    fi2=ceil(popuSize*rand(1,D));
    fi=(pBestFit(fi1) < pBestFit(fi2)).* fi1 + (pBestFit(fi1) >= pBestFit(fi2)) .* fi2;
    bi=ceil(rand(1,D)-1+Pc);
    if bi==zeros(1,D)
        rc=randperm(D);
        bi(rc(1))=1;
    end
    pBestSelected(i,:)=bi.*fi+(1-bi).*pBestSelected(i,:);
end
end