function mutatedIndividual = Mutate(individual, mutationProbability)
    %function that mutates random genes in an individual with a
    %probability.
    
    nGenes = size(individual,2);
    mutatedIndividual = individual;
    a = individual;
%     fprintf('mutation %d\n',size(unique(a),2))
    for j = 1:nGenes
        r = rand;
        if (r < mutationProbability)
            
            ind = randi(144,1);
            while sum(mutatedIndividual == ind) ~= 0
                ind = randi(144,1);
            end
            mutatedIndividual(j) = ind;
            
        end
    end
%     fprintf('mutation %d %d\n',size(unique(a),2), size(unique(mutatedIndividual),2))

end