function [pop,pop_NA,pop_indices] = crossover(wf,pop,pop_NA,pop_indices,pop_size,n_parents,parents_ind,parent_layouts,parent_pop_indices)

for n_counter=1:pop_size
    male = (randi(n_parents));
    female = (randi(n_parents));
    if male ~= female
        cross_point = randi(wf.turbine_num-1)+1;
        
        index1 = parent_pop_indices(male, cross_point-1);
        index2 = parent_pop_indices(female, cross_point);
        if  index1 < index2
            pop(n_counter, :) = 0;
            pop(n_counter, 1:index1) = parent_layouts(male,1:index1);
            pop(n_counter, index2:end) = parent_layouts(female,index2:end);

%             disp(sum(pop(n_counter,:)))
            pop_NA(n_counter, :) = pop(n_counter, :);
            for i = wf.NA_loc
                pop_NA(n_counter,i)=2;
            end
            pop_indices(n_counter, 1:cross_point-1) = parent_pop_indices(male, 1:cross_point-1);
            pop_indices(n_counter, cross_point:end) = parent_pop_indices(female, cross_point:end);
        end
    end
end
end