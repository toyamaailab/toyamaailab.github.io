
function [pop,pop_NA,pop_indices] = windfarm_init_binary(popsize, wf)
%% original 

    
    index =1:wf.rows* wf.cols;
    index(wf.NA_loc)=[];
    rand_index = randperm(length(index));
    index = index(rand_index);
    pop = zeros(popsize,wf.rows* wf.cols);
    pop_NA = zeros(popsize,wf.rows* wf.cols);
    pop_indices = zeros(popsize, wf.turbine_num);
    for i = 1: popsize
        rand_index = randperm(length(index));
        index = index(rand_index);
        pop_indices(i, :) = index(1:wf.turbine_num);
        pop(i,pop_indices(i, :)) = 1;
        pop_NA(i,pop_indices(i, :)) = 1;
    end
    lu = [1 * ones(1, wf.turbine_num); wf.rows* wf.cols * ones(1, wf.turbine_num)];
    pop_indices = sort(pop_indices,2);
end


    
