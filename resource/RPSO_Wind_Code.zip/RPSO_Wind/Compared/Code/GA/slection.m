function [n_parents,parents_ind,parent_layouts,parent_layouts_NA,parent_pop_indices] = slection(pop,pop_NA,pop_indices,pop_size,elite_rate,random_rate)

n_elite = floor(pop_size * elite_rate);
parents_ind = 1:n_elite;

for i =n_elite:pop_size
    if rand > random_rate
        parents_ind  =[parents_ind,i];
    end
end
n_parents = length(parents_ind);
parent_layouts = pop(parents_ind, :);
parent_layouts_NA = pop_NA(parents_ind, :);
parent_pop_indices = pop_indices(parents_ind, :);
 
end