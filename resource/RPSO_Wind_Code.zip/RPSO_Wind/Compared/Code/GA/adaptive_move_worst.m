function [pop,pop_NA,pop_indices,power_order] = adaptive_move_worst(wf,pop,pop_NA,pop_indices,popsize,power_order)
    
    for i =  1:popsize
        turbine_pos = power_order(i,1);
        while 1
            null_turbine_pos = randi(wf.cols*wf.rows);
            if pop_NA(i, null_turbine_pos)==0
                break
            end
        end
        pop(i,turbine_pos) = 0;
        pop(i,null_turbine_pos) = 1;
        pop_NA(i,turbine_pos) = 0;
        pop_NA(i,null_turbine_pos) = 1;
        
        power_order(i, 1) = null_turbine_pos;
        pop_indices(i, :) = sort(power_order(i, :));
    end
end