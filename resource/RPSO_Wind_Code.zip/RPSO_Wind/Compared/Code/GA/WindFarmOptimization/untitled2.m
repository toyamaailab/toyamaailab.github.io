clear
clc
a = zeros(1,144);
index = randperm(144,25);
wf.rows=12;wf.turbine_num=25 ; wf.cols = 12;

x = floor((index-1) / 12);
y = floor(index - 1 - x * 12);
% index1 = sort(index);
% a(index) = 1;
% [x,y] = transiton(a,wf);
% 
index_1 = x*12+y +1;
index_1 - index