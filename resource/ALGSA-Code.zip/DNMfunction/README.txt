21 DNM train 3-bit XOR
22 DNM train Ballon
23 DNM train Iris
24 DNM train Breast Cancer
25 DNM train Heart
26 DNM train Sigmoid
27 DNM train Cosine
28 DNM train Sine
29 DNM train Sphere
210 DNM train Griewank
211 DNM train Rosenbrock
221 DNM train mackey
222 DNM train box
223 DNM train eeg

��ͬ����ά�Ȳ�ͬ
k��qs�����ο����� Dendritic Neuron Model With Effective Learning Algorithms for Classification, Approximation, and Prediction