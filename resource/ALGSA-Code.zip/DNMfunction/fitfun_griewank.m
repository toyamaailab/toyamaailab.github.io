function z = fitfun_griewank( x,y )
%x y z Ϊ����
z = 1/4000*(x^2 + y^2) - cos(x/sqrt(1))*cos(y/sqrt(2)) +1;

end

