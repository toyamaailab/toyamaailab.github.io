function [G,count_list,success_list,ratio,G_flag] = Gconstant(iteration,max_it,N,count_list,success_list,limit,p,a)

alfa=20;G0=100;
G_flag = zeros(1,100);
G = zeros(N,1);
%original
% G=G0*exp(-alfa*iteration/max_it); %eq. 28.g
for i = 1:N
    % Calcualtion the exponential gravitational constant
    G(i) = G0*exp(-alfa*iteration/max_it);
    
    int = count_list(i) > limit;
    suc = success_list(i) > limit;
    pro = rand < p;
    flag1 = suc & pro; % success case
    flag = int & pro;% failure case
    
    % Calculate the ratio of adjusted amplitude.
    temp_a = sqrt(sum(a(i,:).^2,2));
    if  temp_a == 0
        ratio = 1 / rand;
    else
        ratio = abs((log(G(i))-log(temp_a)));
    end
    if ratio < 1
        ratio = 1 / ratio;
    end
    
    if flag
        G(i) = G(i) .* ratio; % abs((log(G(i))-log(temp_a)));
        count_list(i) = 0;
        G_flag(i) = 1;
    end
    if flag1
        G(i) = G(i) .*ratio; % abs((log(G(i))-log(temp_a)));
        success_list(i) = 0;
        G_flag(i) = 2;
    end
   % The boundary control of G.
    if G(i) > G0
        G(i)= G0;
    end
    
end


