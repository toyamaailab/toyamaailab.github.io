function [train_data,train_target,test_data,test_target] = read_data(problem_name)

addpath('.\Dataset');
switch problem_name
    %% classification
    
    case 'Madelon'
        load('Madelon_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);    
    case 'SpectEW'
        load('SpectEW_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);
    case 'Sonar'
        load('SonarEW_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);
    case 'Musk'
        load('Musk_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);
    case 'Hillvalley'
        load('Hillvalley_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);
    case 'Exactly'
        load('Exactly_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);
    case 'CongressEW'
        load('CongressEW_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);
    case 'Ionosphere'
        load('IonosphereEW_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);
    case 'Australia'
        load('Australia_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
  
        test_data = data.test;
        test_target = data.testLabel(:,1);
    case 'KrVsKpEW'
        load('KrVsKpEW_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);
     case 'BreastEW'
        load('BreastEW_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);     
     case 'German'
        load('German_data.mat','data');
        train_data = data.train;
        train_target = data.trainLabel(:,1);
        
        test_data = data.test;
        test_target = data.testLabel(:,1);

    case 'Heart'
        load('Heart297.mat','heart297');
        train_data = heart297(:,1:10);
        train_target = heart297(:,11);
        test_data = heart297(:,1:10);
        test_target = heart297(:,11);
     
        
end
end
