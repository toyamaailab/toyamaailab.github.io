function Arch = UpdArch(Arch, pop, funvalue)
if Arch.NP == 0, return; end
if size(pop, 1) ~= size(funvalue,1), error('check it'); end
popAll = [Arch.Pop; pop ];
funvalues = [Arch.OF; funvalue ];
[dummy,IX]= unique(popAll, 'rows');
if length(IX) < size(popAll, 1) 
  popAll = popAll(IX, :);
  funvalues = funvalues(IX, :);
end
if size(popAll, 1) <= Arch.NP   
  Arch.Pop = popAll;
  Arch.OF = funvalues;
else                
  rndPos = randperm(size(popAll, 1)); 
  rndPos = rndPos(1 : Arch.NP);
  Arch.Pop = popAll  (rndPos, :);
  Arch.OF = funvalues(rndPos, :);
end
end  