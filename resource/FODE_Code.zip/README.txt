#Paper:  Fractional Order Differential Evolution

All the code of the FODE is contained in "FODE.cpp" file.
For compilation you will also need "cec17_test_func.cpp", provided by the competition organizers.
To run the code, you will need the "input_data" folder, containing the functions shift and rotation data.

Compilation is simple using gcc/g++:

g++ FODE.cpp -o FODE.exe -std=c++11 -O3 -march=corei7-avx -fexpensive-optimizations -fomit-frame-pointer

Please note that the compilation requires support of C++11 standard.


