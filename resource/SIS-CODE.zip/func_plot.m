function func_plot(problemIndex)
% clear;close all
global initial_flag

% Xmin=[-100,-100,-100,-100,-100,-100,0,-32,-5,-5,-0.5,-pi,-3,-100,-5,-5,-5,-5,-5,-5,-5,-5,-5,-5,2];
% Xmax=[100,100,100,100,100,100,600,32,5,5,0.5,pi,1,100,5,5,5,5,5,5,5,5,5,5,5];

for func_num=problemIndex
    varargin{:}=func_num;
    fhd=str2func('cec17_func');
    if func_num==1 x=-100:2.5:100;y=x; %[-100,100]
    elseif func_num==2 x=-100:2.5:100; y=x;%[-10,10]
    elseif func_num==3 x=-100:2.5:100; y=x;%[-100,100]
    elseif func_num==4 x=-100:2.5:100; y=x;%[-100,100]
    elseif func_num==5 x=-100:2.5:100;y=x; %[-5,5]
    elseif func_num==6 x=-100:1.5:100; y=x;%[-3,1]
    elseif func_num==7 x=-100:1.5:100; y=x;%[-600,600]
    elseif func_num==8 x=-100:1.5:100; y=x;%[-32,32]
    elseif func_num==9 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==10 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==11 x=-100:2.5:100; y=x;%[-0.5,0.5]
    elseif func_num==12 x=-100:2.5:100; y=x;%[-pi,pi]
    elseif func_num==13 x=-100:2.5:100; y=x;%[-3,1]
    elseif func_num==14 x=-100:2.5:100; y=x;%[-100,100]
    elseif func_num==15 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==16 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==17 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==18 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==19 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==20 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==21 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==22 x=-100:1.5:100; y=x;%[-5,5]
    elseif func_num==23 x=-100:1.5:100; y=x;%[-5,5]
    elseif func_num==24 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==25 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==26 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==27 x=-100:2.5:100; y=x;%[-5,5]
    elseif func_num==28 x=-100:2.5:100; y=x;%[-5,5]
    end
    
    initial_flag=0;
    L=length(x);
    P=[];
    
    for i=1:L
        for j=1:L
            % f(i,j)=benchmark_func([x(i),y(j)],func_num);
            P(i,j)=feval(fhd,[y(j),x(i)]',varargin{:});
            %         fitness_popu=fitness_popu';
        end
    end
    colormap(jet);
%     figure(1),surfc(x,y,P);
%     [az,el] = view 
%     view(25,36);
%     figure(1),
    contour(x,y,P,15);
    hold on
end
end

