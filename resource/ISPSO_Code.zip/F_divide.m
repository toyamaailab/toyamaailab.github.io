function [F1,F2,F3] = F_divide(alter_features)
    [~,D] = size(alter_features);
    k1 = fix(0.3 * D);
    [~, F1] = maxk(alter_features,k1);
    k3 = fix(0.3 * D);
    [~, F3] = mink(alter_features,k3);
    all_indices = 1:D;
    F2 = setdiff(all_indices, [F1, F3]);
end


