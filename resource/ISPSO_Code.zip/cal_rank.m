function rank_inf_gain = cal_rank(TrainIn,TrainOut)
%RANK 此处显示有关此函数的摘要
[~,D] = size(TrainIn);
covariance_matrix = cov(TrainIn);
inverse_covariance_matrix = inv(covariance_matrix);
vif = diag(inverse_covariance_matrix);
vif = vif';

information_gain_ratio = calculate_information_gain_ratio(TrainIn,TrainOut);
rank_vif = zeros(1,D);
rank_inf_gain = zeros(1,D);

[~,index_vif] = sort(vif,'descend');
[~,index_inf_gain] = sort(information_gain_ratio,'descend');
for i = 1 : D
    rank_vif(index_vif(i)) = i;
end
for i = 1 : D
    rank_inf_gain(index_inf_gain(i)) = i;
end

% rank_total = rank_vif + rank_inf_gain;
% [sorted_data, sorted_indices] = sort(rank_total);
% 
% % 计算每个元素在排序后的排名
% rank_matrix = zeros(size(rank_total));
% rank_matrix(sorted_indices) = 1:numel(rank_total);
end

