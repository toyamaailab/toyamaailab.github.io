function Positions = initialization(N, D, ub, lb,alter_features,F1,F2,F3)
    Positions = zeros(N,D);
    for i = 1 : N
        rand_N = randperm(3,1);
        switch rand_N
            case 3
                Positions(i,F1) = rand(1,length(F1)) < alter_features(F1);
                F = 1 : D;
                rest = setdiff(F, F1);
                Positions(i,rest) = rand(1,length(rest)) < 0.5;
            case 2
                Positions(i,F2) = rand(1,length(F2)) < alter_features(F2);
                F = 1 : D;
                rest = setdiff(F, F2);
                Positions(i,rest) = rand(1,length(rest)) < 0.5; 
            case 1
                
                Positions(i,F3) = rand(1,length(F3)) < alter_features(F3);
                F = 1 : D;
                rest = setdiff(F, F3);
                Positions(i,rest) = rand(1,length(rest)) < 0.5;
        end

    end
end