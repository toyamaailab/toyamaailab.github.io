function [new_Pop,pop_fitness,p_fitness,V,Pbest,thresold1] = MBPSO(Pop,fitness,p_fitness,Pbest,gbest_individual,eval,Maxeval,N,D,V,Train_data,alter_features,thresold1)
% w = 0.9 - 0.4*(1-eval/Maxeval);
c1 = 0.4;
c2 = 0.9;
w = 0.01;
for i = 1 : N
    V(i,:) = w * V(i,:) + rand(1,D) .* (1-alter_features) .* (Pbest(i,:) - Pop(i,:)) + rand(1,D) .* alter_features .* (gbest_individual - Pop(i,:)) - rand * (rand(1,D) - Pop(i,:));
end
for i = 1 : N
    for j = 1 : D
        if(thresold1(j) <= 0)
            offspring(i,j) = 0;
        else
            if(V(i,j) > rand)
                offspring(i,j) = 1-Pop(i,j);
            else
                offspring(i,j) = Pop(i,j);
            end
        end
        if(V(i,j) > 1)
            V(i,j) = 1;
        elseif(V(i,j) < 0)
            V(i,j) = 0;
        end
       
    end
end

off_fitness = Evaluation(offspring,N,D,Train_data);
[off_sorted,off_index] = sort(off_fitness);
[pop_sorted,pop_index] = sort(fitness);
for i = 1:N
    if(off_fitness(i) < p_fitness(i))
        p_fitness(i) = off_fitness(i);
        Pbest(i,:) = offspring(i,:);                                                      
    end
    if(off_fitness(i) < fitness(i))
        thresold1 = thresold1 - 5 * alter_features .* (Pop(i,:) - offspring(i,:)) ;
    end
    thresold1 = thresold1 + 0.05 * alter_features;
end
new_Pop = zeros(N,D);
pop_fitness = zeros(1,N);
i = 1;
j = 1;
m = 1;
while( i <= N && j <= N)
        if(off_sorted(i) < pop_sorted(j))
            new_Pop(m,:) = offspring(off_index( i),:);
            pop_fitness(:,m) = off_sorted(i);
            i = i + 1;
            m = m + 1;
        else
            new_Pop(m,:) = Pop(pop_index(j),:);
            pop_fitness(:,m) = pop_sorted(j);
            j = j + 1;
            m = m + 1;
        end
        if(m > N)
            break;
        end
end

end


