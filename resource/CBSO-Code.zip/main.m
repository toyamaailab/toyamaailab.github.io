warning off all

clear all
clc
global initial_flag

n_p = 100;    % population size
n_d = 30;    % dimension
n_c = 5;    % number of clusters

for problem = 12;
    
    tic;
    
    [rang_l,rang_r]=test_functions_range(problem);
    
    initial_flag=0;
    
    max_iteration = 1500;    % maximal number of iterations
    
    FbestChart=[];diverChart=[];
    
    for t = 1:1 % run times
        [fit,n_iteration,diver] = BSO(problem,n_p,n_d,n_c,rang_l,rang_r,max_iteration);  %run BSO one time
        
        ['run', num2str(t)]
        
        FbestChart=[FbestChart,fit];
        
        
    end
    
    toc;
%     xlswrite(['C:\Users\����S\Desktop\1.xlsx'],FbestChart,['Sheet',num2str(problem)]);
%     xlswrite(['C:\Users\����S\Desktop\1.xlsx'],mean(FbestChart(max_iteration,:)),['Sheet',num2str(problem)],'A1502');
%     xlswrite(['C:\Users\����S\Desktop\1.xlsx'],std(FbestChart(max_iteration,:)),['Sheet',num2str(problem)],'B1502');
end



