function X_div=Diversity(Positions)

[N,D]=size(Positions);

X=zeros(1,D);

X_uni=zeros(1,N);

A=zeros(N,N);B=zeros(1,1);

X_total=zeros(1,1);

for i=1:N;
    X=X+Positions(i,:);
end

X_avg=X/N;

for i=1:N;
    for j=1:N;
        A(i,j)=norm(Positions(i,:)-Positions(j,:));
    end
    X_uni(i)=norm(Positions(i,:)-X_avg);
    X_total=X_total+X_uni(i);
end
    B=max(max(A));
    X_div=X_total/N/B;
    

