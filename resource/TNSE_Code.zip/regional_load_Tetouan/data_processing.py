import pandas as pd
import numpy as np

def structure_revise():

    # 读取CSV文件
    file_path = 'D:/小论文/小论文1/实验内容/regional_load_Tetouan/raw_data/powerconsumption.csv'
    df = pd.read_csv(file_path)

    # 选择需要保留的列
    selected_columns = ['Datetime', 'PowerConsumption_Zone1', 'Temperature', 'Humidity', 'WindSpeed']
    df = df[selected_columns]

    # 将结果保存到新的CSV文件
    new_file_path = 'D:/小论文/小论文1/实验内容/regional_load_Tetouan/dealed_data/region1_powerconsumption.csv'
    df.to_csv(new_file_path, index=False)



def slice_by_hour():
    # 读取CSV文件
    file_path = 'D:/小论文/小论文1/实验内容/regional_load_Tetouan/dealed_data/region1_powerconsumption.csv'
    df = pd.read_csv(file_path)
    df = df[::6]
    new_file_path = 'D:/小论文/小论文1/实验内容/regional_load_Tetouan/dealed_data/region1_powerconsumption_hourly.csv'
    df.to_csv(new_file_path, index=False)




if __name__ == '__main__':
    slice_by_hour()