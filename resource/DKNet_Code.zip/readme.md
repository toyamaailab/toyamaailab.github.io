### create a virtual environment
### If there is anything you need to install just use pip or conda to install it
'''
You can use the command 'conda create -n yourname', after installing anconda, to create a virtual environment.
Then, use the command "conda activate yourname" to activate the environment you have just created.(In ubuntu os, maybe you should use the command"source activate yourname")
'''

### requirment
### If there is anything you need to install just use pip or conda to install it
'''
einops==0.6.1
matplotlib==3.5.3
MedPy==0.4.0
mmcv==2.0.0
numpy==1.18.1
opencv_python==4.7.0.68
pandas==1.0.1
Pillow==9.5.0
scikit_learn==1.2.2
scipy==1.7.3
spikingjelly==0.0.0.0.14
timm==0.9.2
torch==1.13.1
torchmetrics==0.11.4
torchsummary==1.5.1
torchvision==0.8.2+cpu
tqdm==4.64.1
'''

### Data_dir
```python
├── data
│   ├── BUS
│   ├── Kvasir-SEG
│   ├── STU-Hospital-master


├── bus(Kvasir-SEG, STU-Hospital-master)
│   ├── data_mask
│       ├── images
│       ├── masks

│   ├── data (Only need to create data and data_mask)
│       ├── train
│       ├── trainannot
│       ├── val
│       ├── valannot
│       ├── test
│       ├── testannot
```

### Data_process:
`python data_spilt.py  # Spilt the data. Select data by changing 'filepath' in code`

### K-folder_experiment:
`python k_folder.py --log_name "./log/log_name.log" --data_name bus --batch_size 6 --EPOCH 100 --LR 0.00005 --DNM1 1 --DNM2 1 --M 10`

### Comparative_experiment:
`python compare_kfold.py --log_name "./log/log_name.log" --data_name bus --model_name unet --batch_size 6 --EPOCH 100 --LR 0.00005`
### Comparative_experiment_RRCNet:
`python kfolder_RRC.py --log_name "./log/log_name_RRC.log" --data_name bus --batch_size 6 --EPOCH 100 --LR 0.00005 --DNM1 0 --DNM2 0`

### Pic_experiment(to save model.pth):
`python unet_train.py --log_name "./log/log_name.log" --data_name bus --batch_size 6 --EPOCH 100 --LR 0.00005 --LOSSK 0.1 --DNM1 1 --DNM2 1 --M 10`
`python unet_compare_train.py --log_name "./log/log_name.log" --data_name bus --batch_size 6 --EPOCH 100 --LR 0.00005`

### Pic_plot:
`python predicted.py`
`python predicted_other_model.py`
`predicted_other_model_pic.py  # If the number of pictures and the name of the model are changed, the file needs to be changed.` 
