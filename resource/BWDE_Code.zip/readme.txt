/*#Paper:  Best-worst Individuals Driven Multiple-layered Differential Evolution

All the code of the BWDE is contained in "BWDE.cpp" file.
Compilation is simple using gcc/g++:
g++ BWDE.cpp -o BWDE.exe -std=c++11 -O3 -march=corei7-avx -fexpensive-optimizations -fomit-frame-pointer

Please note that the compilation requires support of C++11 standard.
You may omit everything after "-O3", however, these options give a significant boost on most systems.
This will create BWDE.exe, available for running.