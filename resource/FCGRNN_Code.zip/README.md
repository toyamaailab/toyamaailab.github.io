# FCGRNN
FCGRNN: Fully Complex Deep Gated Recurrent Neural Network for Ultrasound Imaging

Ultrasound imaging is widely used in medical diagnosis. We propose a fully complex deep gated recurrent neural network to directly handle complex-valued ultrasound signals for improving image quality. The proposed model considers the time attribution of signals and a complete complex number calculation.

## Environment
1. ubuntu 20.04
2. python3.7
3. tensorflow==1.15

Other packages please reference ``requirements.txt``
## Get started
1. Install python3.7, tensorflow==1.15. You can train the model by 
```command line
sh run.sh
```

## Using Docker
To easily reproduce the results using Docker, conda and Make, you can follow the next steps:
1. Get images `make init `
2. Training model by using `make run_module module="bash ./run.sh`