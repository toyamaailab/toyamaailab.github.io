
python  run.py --is_training 1 \
        --dataset_path ./dataset\
        --outputs_type mean\
        --dim_reduce 1\
        --num_units 128\
        --num_proj 1\
        --abs_layer 1\
        --dense 64 1\
        --dropout 0.9\
        --learning_rate 1e-3\
        --momentum 1.0 \
        --runs 2
        
