import os 
import numpy as np
import argparse
parse = argparse.ArgumentParser()
'/home/lzy/UltrasonicPrediction/Dataset/ultrasonic_data/dataset_mat/original/data40.mat'
parse.add_argument('--path', '-p', type=str, default='/home/lzy/UltrasonicPrediction/Dataset/ultrasonic_data/Sample_100_complex', help='Setting the batch size, default value is 16.')
parse.add_argument('--data_type','-t',type=int,default=1)
args = parse.parse_args()

data_type = args.data_type
data_path = args.path

if data_type == 1:
    a = np.arange(100)
    np.random.shuffle(a)
    print(a)
    train_index = a[:70]
    test_index = a[70:]
    f = open('train_index.txt','w')

    for i in train_index:
        file_path = os.path.join(data_path, 'data%d.mat'%i)
        print(file_path)
        f.write(file_path + '\n')
    f.close()
    f = open('test_index.txt','w')
    for i in test_index:
        file_path = os.path.join(data_path, 'data%d.mat'%i)
        print(file_path)
        f.write(file_path + '\n')
    f.close()
elif data_type==2:
    name = ['test_carotid_teacher', 'test_cyst_teacher', 'test_simulation_cyst_teacher', 'test_simulation_point_teacher',
            'test_string_teacher']
    f = open('train_image.txt','w')

    for i in name:
        file_path = os.path.join(data_path, i) + '.mat'
        print(file_path)
        f.write(file_path + '\n')
    f.close()
    f = open('test_image.txt','w')
    for i in name:
        file_path = os.path.join(data_path,i) + '.mat'
        print(file_path)
        f.write(file_path + '\n')
    f.close()
    





