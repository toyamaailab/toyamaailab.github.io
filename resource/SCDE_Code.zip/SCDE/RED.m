function R = RED(u1,u2)


a_centered = u1;
b_centered = u2;

cos_sim = dot(a_centered, b_centered) / (norm(a_centered) * norm(b_centered));
R = cos_sim^2;
end

