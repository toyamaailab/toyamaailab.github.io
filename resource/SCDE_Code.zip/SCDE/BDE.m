function [Popu,off_fitness,gBest,gBest_individual,oldgBest,c] = BDE(Popu,pop_fitness,D,N,Train_data,c,gBest,gBest_individual,I,meansu,F,nFES,FES,oldgBest,gain,t_mi)

for i = 1:N  
    for d = 1:D
       R     = randperm(N);  
    r1    = R(1);
    r2    = R(2);
    r3    = R(3);
        value =gBest_individual(1,d)+F*(Popu(r2,d)-Popu(r1,d));
          if value>0
              MV(i,d)=1;
          else
              MV(i,d)=0;
          end
    end
 end

 
    if oldgBest==gBest
        c=c+1;
    else
        c=0 ;
    end

for idx=1: N
    counter=0;
   for jdx=1:N
      if idx==jdx
            RE(idx,jdx)=0;
      else 
       RE(idx,jdx) =RED(MV(idx,:), MV(jdx,:));  
      end
   end
   for jdx=1:N

   if RE(idx,jdx) >0.5
       counter=counter+1;
   end
   end

if counter>0.3*N
     [~, index]=max(RE(idx,:));
         a = find(and(MV(index, :), MV(idx, :)));   
         x = find(~ MV(idx, :));
        [~,sa] =size(a);
        sa=ceil(sa/2)+1;
   
        index = TS(t_mi(a),sa);
         MV(idx,a(index)) = 0;
       
       index = TS(-t_mi(x),sa);
         MV(idx,x(index)) = 1;
end 
            
end
    
    


 
 Offspring=MV;



Offspring=unique(Offspring,'rows');
 s=size(Offspring,1);
 if s~=N
 e=N-s;
 Offspring2=[];
   for i=1:e
      for d = 1:D
          Offspring2(i,d)=round(rand);
       end
   end
    Offspring= [Offspring;Offspring2];

 end
   



for i = 1:N
    if off_fitness(i) <= pop_fitness(i)
        Popu(i,:) = Offspring(i,:);
        pop_fitness(i) = off_fitness(i);
    end
    if pop_fitness(i) < gBest
        gBest = pop_fitness(i);
        gBest_individual  = Popu(i,:);
    end
end
oldgBest=gBest;
end
function index = TS(t_mi,sa)
% Binary tournament selection
if isempty(t_mi)
index = [];
else
% n=randi(t-1,1);
index = TournamentSelection(sa,1,t_mi);
end
end
