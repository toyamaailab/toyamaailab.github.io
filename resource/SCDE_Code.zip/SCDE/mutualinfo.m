function h = mutualinfo(vec1,vec2)

[p12, p1, p2] = estpab(vec1,vec2);

h = estmutualinfo(p12,p1,p2);

end

