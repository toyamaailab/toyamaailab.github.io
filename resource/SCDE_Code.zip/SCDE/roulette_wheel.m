function [ a,clas_def ] = roulette_wheel( total ,d)
m=zeros(1,length(total));
cdf(1)=total(1);
s=length(total);
meantotal=sum(total)/(s-d+1);
for i=2:length(total)
    cdf(i)=cdf(i-1)+total(i);
end
    q=rand;
    for i=1:length(total)
        if q<cdf(i)
            m(i)=1;
            break;
        end
    end
a=find(m==1);

if(total(a)<meantotal)                   
    
    clas_def=0;
else
    clas_def=1;
end

