% function [array] = Initialize_firstpop(Buoy_Number,VarMin,VarMax,Safe_Distance)
% 
% flag  = 0;
% arx   = zeros(1,Buoy_Number*2);
% 
% while (flag==0)
%     flag  = 1;
%     arx   = unifrnd(VarMin,VarMax,[1 Buoy_Number*2]);
%     i     = 1;
%     j     = 1;
%     % finding feasible position of Buoys
%     while i<=(Buoy_Number*2)-3
%         j = i+2;
%         while j<(Buoy_Number*2)  % calculating safe distance among buoys
%             sq1 = power((arx(i)-arx(j)),2);
%             j   = j+1;
%             sq2 = power((arx(i+1)-arx(j)),2);
%             j   = j+1;
%             cal = sqrt (sq1+sq2);
%             
%             if (cal <Safe_Distance)
%                 flag=0;
%                 break
%             end
%         end % end second while
%         if (flag==0)
%             break;
%         end
%         i=i+2;
%     end % end first while
%     array.number                 = Buoy_Number;
%     array.radius                 = 5* ones(1,array.number);
%     array.qW                     = [];
%     array.ParrayW                = [];
%     array.ParrayBuoyW            = [];
%     array.sphereCoordinate(1:2,:)= reshape(arx,[2 Buoy_Number]);
%     array.sphereCoordinate(3,:)  = -8;
%         
% end

function [c] = Initialize_firstpop(Buoy_Number,VarMin,VarMax,Safe_Distance)

flag  = 0;
arx   = zeros(1,Buoy_Number*2);

while (flag==0)
    flag  = 1;
    arx   = unifrnd(VarMin,VarMax,[1 Buoy_Number*2]);
    i     = 1;
    j     = 1;
    % finding feasible position of Buoys
    while i<=(Buoy_Number*2)-3
        j = i+2;
        while j<(Buoy_Number*2)  % calculating safe distance among buoys
            sq1 = power((arx(i)-arx(j)),2);
            j   = j+1;
            sq2 = power((arx(i+1)-arx(j)),2);
            j   = j+1;
            cal = sqrt (sq1+sq2);
            
            if (cal <Safe_Distance)
                flag=0;
                break
            end
        end % end second while
        if (flag==0)
            break;
        end
        i=i+2;
    end % end first while
    array.number                 = Buoy_Number;
    array.radius                 = 5* ones(1,array.number);
    array.qW                     = [];
    array.ParrayW                = [];
    array.ParrayBuoyW            = [];
    c = reshape(arx,[1 Buoy_Number*2]);
%     array.sphereCoordinate(1:2,:)= reshape(arx,[1 Buoy_Number*2]);
%     array.sphereCoordinate(3,:)  = -8;
%     c=array.sphereCoordinate(1:2,:);
        
end