function [ParrayW, ParrayBuoyW, qW]=transformation(Nvar,arx, siteOpts, buoy,par)

array.number                    = Nvar/2;
array.radius                    = 5*ones(1, (Nvar/2));
arxx = zeros(1,4);
arxy = zeros(1,4);

for i=1:array.number
    arxx(i) = arx((2*i-1));
end
for i=1:array.number
    arxy(i) = arx((2*i));
end
array.sphereCoordinate(1,:)     = arxx;
array.sphereCoordinate(2,:)     = arxy;
array.sphereCoordinate(3,:)     = -8;
if par==0
 [ParrayW, ParrayBuoyW, qW]     = arrayBuoyPlacement_v20180601(array, siteOpts, buoy);  
else
 [ParrayW, ParrayBuoyW, qW]     = arrayBuoyPlacement_v20180601_par(array, siteOpts, buoy);
end

end




