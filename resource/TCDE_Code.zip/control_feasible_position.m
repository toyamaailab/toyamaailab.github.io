function [flag]= control_feasible_position(y,nVar,flag)
ii=1;
j=1;
while ii<=nVar-3
    j=ii+2;
    while j<nVar  % calculating safe distance among buoys
        sq1 = power((y(ii)-y(j)),2);
        j   = j+1;
        sq2 = power((y(ii+1)-y(j)),2);
        j   = j+1;
        cal = sqrt (sq1+sq2);
        
        if (cal <50)
            flag=0;
            break
        end
    end % end second while
    if (flag==0)
        break;
    end
    ii=ii+2;
end % end first while
end