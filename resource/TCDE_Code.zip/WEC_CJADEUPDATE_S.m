function []=WEC_CJADEUPDATE_S(WaveModel,Max_Buoy_Num,Safe_Distance,id, par)

slCharacterEncoding('US-ASCII')
slCharacterEncoding()

rand('seed', sum(100 * clock));
%% run
%% Fix here to choose which algorithm of CJADE and SCJADE is wanted.
disp('CJADE Evolution is running')
disp(['The maximum buoy (WEC) number in the wave farm = ',num2str(Max_Buoy_Num)])
Strategy = 4; % Fix here to make sure which algorithm of CJADE and SCJADE is wanted.
dateget = datestr(now,30);
new_folder = ['./resultsave/',dateget];
mkdir(new_folder);

switch WaveModel
    
    case 1  % Perth
        fname = 'HCtimeseries_aus_4m_114.80E_33.50S.nc';
        siteName = 'Perth';
        disp('Perth wave model')
    case 2  % Adelaide
        fname = 'HCtimeseries_aus_4m_136.62E_36.07S.nc';
        siteName = 'Adelaide';
         disp('Adelaide wave model')
    case 3  % Tasmania
        fname = 'Tasmania_145.0372E_42.8175S.nc';
        siteName = 'Tasmania';
         disp('Tasmania wave model')
    case 4  % Sydney
        fname = 'HCtimeseries_aus_4m_152.50E_34.00S.nc';
        siteName = 'Sydney';
         disp('Sydney wave model')
end
%%


time    = ncread(fname,'time');
hs      = ncread(fname,'hs');
fp      = ncread(fname,'fp');
tm0m1   = ncread(fname,'tm0m1');
dirWave = ncread(fname,'dir');

n1 = length(find(time==-32767));
n2 = length(find(hs==-32767));
n3 = length(find(fp==-32767));
n4 = length(find(tm0m1==-32767));
n5 = length(find(dirWave==-32767));

nMax = max([n1, n2, n3, n4, n5]);

time(1:nMax)    = [];
hs(1:nMax)      = [];
fp(1:nMax)      = [];
tm0m1(1:nMax)   = [];
dirWave(1:nMax) = [];

dirWave(dirWave == 360) = 0;

%% 4D Histogram (wave height, wave period, wave direction)
xbins_hs = 0.5:1:[ceil(max(hs))+0.5];
xbins_tp = round(1/max(fp)):1:round(1/min(fp));
xbins_wa = 0:15:360;

[counts, edges, mid, loc] = histcn([hs 1./fp dirWave], xbins_hs, xbins_tp, xbins_wa);

%% Detect significant wave directions
N_hist_wa = squeeze(sum(sum(counts, 1), 2));

[N_hist_wa_sort, I_wa_sort] = sort(N_hist_wa, 'descend');

n_wa = 0;
ii = 0;
while n_wa < 0.90
    ii = ii + 1;
    n_wa = n_wa + N_hist_wa_sort(ii)/sum(N_hist_wa_sort);
end

I_wa = sort(I_wa_sort(1:ii));

%% Detect significant wave heights
N_hist_hs = squeeze(sum(sum(counts, 3), 2));

[N_hist_hs_sort, I_hs_sort] = sort(N_hist_hs, 'descend');

n_hs = 0;
ii = 0;
while n_hs < 0.90
    ii = ii + 1;
    n_hs = n_hs + N_hist_hs_sort(ii)/sum(N_hist_hs_sort);
end

I_hs = sort(I_hs_sort(1:ii));

%% Detect significant peak wave periods
N_hist_tp = squeeze(sum(sum(counts, 1), 3));

[N_hist_tp_sort, I_tp_sort] = sort(N_hist_tp, 'descend');

n_tp = 0;
ii = 0;
while n_tp < 0.90
    ii = ii + 1;
    n_tp = n_tp + N_hist_tp_sort(ii)/sum(N_hist_tp_sort);
end

I_tp = sort(I_tp_sort(1:ii));

%% Data reduction
N_hist          = counts(I_hs, I_tp, I_wa);
Hs_hist         = mid{1}(I_hs);
Tp_hist         = mid{2}(I_tp);
waveAngle_hist	= mid{3}(I_wa);

%% Define the parameters you want to run the model
siteOpts.waterDepth         = 30;                % Water depth
siteOpts.submergenceDepth   = 3;                 % Submergence depth of the buoy (from the water level to the top of the buoy)
siteOpts.waveFreqs          = linspace(0.2, 2, 50);
siteOpts.location.siteName  = siteName;
siteOpts.location.Hs        = Hs_hist;
siteOpts.location.Tp        = Tp_hist;
siteOpts.location.waveAngle = waveAngle_hist*pi/180;
siteOpts.location.N_hist    = N_hist;
%%%%%%%%
array.radius = 5*ones(1,Max_Buoy_Num );

% Parameters of the indivudual buoy
buoy.mass           = 3.7568e5;     % kg
buoy.volume         = 523.5988;     % m^3
buoy.tetherAngle	= 0.9553;       % rad
buoy.kPTO           = 407510;       % N/m
buoy.dPTO           = 97412;        % N/(m/s)
%% Calculate power for one buoy with given parameters
rho     = 1025;
g       = 9.80665;

wave.waterDensity	= rho;
wave.angle          = 0;
numApprox           = 4;

mass	= buoy.mass;
V       = buoy.volume;
Ft      = (rho*g*V - mass*g);

PowerIsolated = zeros(length(siteOpts.waveFreqs), 1);

for count_w = 1:length(siteOpts.waveFreqs)
    
    w = siteOpts.waveFreqs(count_w);
    
    K = w^2/g;
    
    % Structure of the isolated sphere
    sphere.radius           = array.radius(1);
    sphere.massMatrix       = eye(3)*mass;
    sphere.tetherPretention = Ft;
    sphere.number           = 1;
    sphere.sphereCoordinate = [0; 0; -(siteOpts.submergenceDepth + array.radius(1))];
    sphere.oceanDepth       = siteOpts.waterDepth;
    sphere.submergenceDepth = siteOpts.submergenceDepth + array.radius(1);
    sphere.waveAngle        = 0;
    sphere.tetherAngle      = buoy.tetherAngle;
    
    % Array hydrodynamics
    [A, Bd, X] = arraySubmergedSphereParfor(sphere, wave, w, K, numApprox, 1);
    
    sphere.addedMass = A;
    sphere.damping = Bd;
    sphere.excitationForce = X;
    sphere.waveFrequency = w;
    sphere.waveNumber = K;
    
    [PowerIsolated(count_w), ~, ~, ~] = powerFunSphere([buoy.kPTO buoy.dPTO], sphere);
    
end

buoy.PowerIsolated = PowerIsolated;

runTime = 8;
intertimes = 300;
D = Max_Buoy_Num*2;

parent.number = Max_Buoy_Num;
area            = round(sqrt(parent.number*20000)) % enviromental dimension
nVar            = (round(area/50)+1)^2 ;
VarMin          = 0;                          % Lower Bound of Decision Variables
VarMax          = area;                       % Upper Bound of Decision Variables
popuSize = 50;
FES = 1 * 10^4 * D;
addpath('../../');
fordisptemplo = zeros(intertimes,Max_Buoy_Num*2);
fordisptemp = zeros(1,intertimes);
    resultChart = [];
    t = 1;

    %% Generation of chaotic
        switch Strategy % Please use 3 and 4.
            case 0
                circle = ceil(FES / 101) + 1;
            case 1
                circle = ceil(FES / 101) + 1; % Maximum numbef of iterations 4839 & 3572
            case 2
                circle = ceil(FES / 101) + 1;
            case 3
                algorithmDir = 'SCJADE';
                circle = ceil(FES / 101) + 1;
                LEP = 24;
            case 4
                algorithmDir = 'CJADE';
                circle = ceil(FES / 101) + 1;
                LEP = 50;
        end
        Chaos_p = GenerateChaos(circle);
while t <= runTime
%% init of each run
% FES count
id=id+1;
nFES = 0;

%results putinto txt

filename = ['.\resultsave','\',dateget,'\CJADEM2' ,num2str(t), '.txt'];
fid = fopen(filename,'w'); 

for v=1:intertimes
    fprintf(fid,'Best Layout=%d %d %d %d %d %d %d %d \n',fordisptemplo(v,:));
    fprintf(fid,'The Interation %d BestOutput:',v);
    fprintf(fid,' %d\n',fordisptemp(v));
end

fclose(fid);

% iteration count
iter = 0;
% optimalChart = [];
% Population initialization
lu = [VarMin*ones(1,D);VarMax*ones(1,D)];

%%  parameters
rth = zeros(popuSize,2*Max_Buoy_Num);
for i=1:popuSize
    rth(i,:) = Initialize_firstpop(Max_Buoy_Num,VarMin,VarMax,Safe_Distance);
end
popu = rth;

% dimension for certain problem
D = size(popu,2);

% algorithms' specific population names
popold = popu;
% program start here
radius = 0.01;
c = 1/10;
%         p = 0.05;
CRm = 0.5;
Fm = 0.5;
Afactor = 1;

archive.NP = Afactor * popuSize;     % the maximum size of the archive
archive.pop = [];          % the solutions stored in te archive
archive.funvalues = zeros(0, 1);    % the function value of the archived solutions

ns = [];
nf = [];
pfit = ones(1, 12);
normfit = zeros(1,12);

k_circle = 1;
CR_circle = zeros(1,circle);
F_circle = zeros(1,circle);

% Population evaluation
% par=0;
%gcp();
%pctRunOnAll warning off
parfor k=1:popuSize % evaluating the layouts

[ParrayW, ParrayBuoyW, qW] = transformation(Max_Buoy_Num*2, popu(k,:), siteOpts, buoy,par);

parent(k).qW               = qW;
parent(k).ParrayW          = ParrayW;
parent(k).ParrayBuoyW      = ParrayBuoyW;



end


for q=1:popuSize
firstpopPW(q) = parent(q).ParrayW;
end

%% the values and indices of the best solutions
[valBest, indBest] = sort([parent(:).ParrayW], 'descend');
%%

%         BciSolution = zeros(1, D);

pgoodtemp = zeros(popuSize,D);
pgood = zeros(popuSize,D);

while nFES <= FES
    iter = iter + 1;
    if iter>intertimes
%                 save([siteName,'-Model_NB=',num2str(Max_Buoy_Num),'Npop=',num2str(popuSize),'_id_',num2str(id),'.mat'],'firstpopPW');
        disp(['The No.' num2str(t) 'time was over'])
        break
    end


    %% Chaotic local search
    if Strategy > 0
        lb = lu(1,:);ub = lu(2,:);
        randPopuList = randperm(popuSize);
        randPopuList = setdiff(randPopuList,1,'stable');
%                 indiR1 = popold(randPopuList(1),:);
%                 indiR2 = popold(randPopuList(2),:);
        z = 0.5;
        g = k_circle;
%                 radius = 0.01 * (1-FES/D*10000);
        switch Strategy
            case 1

            case 2

            case 3

            case 4
                % Stochastic universal sampling
                rr = rand;
                j = 1;
                partsum = 0;
                for i = 1: 12
                    normfit(i) = pfit(i) / sum(pfit);
                end
                while partsum < rr
                    partsum = partsum + normfit(j);
                    j = j + 1;
                end
                select = j - 1;

                lpcount = [];
                npcount = [];
                temp_X = popold(indBest(1),:) + radius * (ub-lb) * (Chaos_p(select,g) - z);%r=0.1

                tp = temp_X > ub;
                tm = temp_X < lb;
                temp_X = (temp_X .* (~(tp + tm))) + ub .* tp + lb .* tm;

                %        fit_temp = benchmark_func(temp_X, problem, o, A, M, a, alpha, b);


                [ParrayW0, ParrayBuoyW, qW] = transformation(Max_Buoy_Num*2, temp_X, siteOpts, buoy,par);


                if ParrayW0 > valBest(1)
                    popold(indBest(1),:) = temp_X;
                    valBest(1) = ParrayW0;

                    tlpcount = zeros(1, 12);
                    tlpcount(select) = 1;
                    lpcount = [lpcount;tlpcount];

                    tnpcount = ones(1, 12);
                    tnpcount(select) = 0;
                    npcount = [npcount;tnpcount];
                else
                    tlpcount = zeros(1,12);
                    lpcount = [lpcount;tlpcount];
                    tnpcount = ones(1,12);
                    npcount = [npcount;tnpcount];
                end

                ns = [ns; sum(lpcount, 1)];
                nf = [nf; sum(npcount, 1)];

                %success and failure memory
                if k_circle+1 >= LEP
                    for i = 1 : 12
                        if (sum(ns(:, i)) + sum(nf(:, i))) == 0
                            pfit(i) = 0.01;%to avoid the possible null success rates
                        else
                            pfit(i) = sum(ns(:, i)) / (sum(ns(:, i)) + sum(nf(:, i))) + 0.01;
                        end
                    end
                    if size(ns,1) > LEP
                        ns(1, :) = [];
                    end
                    if size(nf,1) > LEP
                        nf(1, :) = [];
                    end
                end
        end
        radius = radius * 0.988;
    end
    %%
    CR_circle(k_circle)=CRm;
    F_circle(k_circle)=Fm;

    pop = popold; % the old population becomes the current population

    if iter> 1 && ~isempty(goodCR) && sum(goodF) > 0 % If goodF and goodCR are empty, pause the update
        CRm = (1 - c) * CRm + c * mean(goodCR);
        Fm = (1 - c) * Fm + c * sum(goodF .^ 2) / sum(goodF); % Lehmer mean
    end

    % Generate CR according to a normal distribution with mean CRm, and std 0.1
    % Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
    [F, CR] = randFCR(popuSize, CRm, 0.1, Fm, 0.1);
    popAll = [pop; archive.pop];
    [r1, r2] = gnR1R2(popuSize, size(popAll, 1));%%%%%%%%%%%%%%%popAll first D%%%%%%%%%%%%%%%%%%%%%

    % Find the p-best solutions
    pNP = max(round(0.05 * popuSize), 2);            % choose at least two best solutions
    randindex = ceil(rand(1, popuSize) * pNP);    % select from [1, 2, 3, ..., pNP]
    randindex = max(1, randindex);               % to avoid the problem that rand = 0 and thus ceil(rand) = 0
    pbest = pop(indBest(randindex), :);          % randomly choose one of the top 100p% solutions

    %proportion to generatic as good sorting
%     for i = 1:10
%         for j = (5*i-4):5*i
%             pgoodtemp(j,:) = pop(indBest(j),:); 
%         end
%     end      
% 
%     r = [0,1/10,2/10,3/10,4/10,5/10,6/10,7/10,8/10,9/10];
%     for p = 1:10
%         e = round(44*rand(1,1))+1;   
%         if e>0&&e<10
%             q=0;
%             for i = 1:5
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         elseif e>9&&e<18
%             q=0;
%             for i = 6:10
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         elseif e>17&&e<25
%             q=0;
%             for i = 11:15
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         elseif e>24&&e<31
%             q=0;
%             for i = 16:20
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         elseif e>30&&e<36
%             q=0;
%             for i = 21:25
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         elseif e>35&&e<40
%             q=0;
%             for i = 26:30
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         elseif e>39&&e<43
%             q=0;
%             for i = 31:35
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         elseif e>42&&e<45
%             q=0;
%             for i = 36:40
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         elseif e==45
%             q=0;
%             for i = 41:45
%             pgood(5*p-4+q,:) = pgoodtemp(i,:);
%             q=q+1;
%             end
%         end
%     end                                                                          
% 
%     pop = pgood;

    % == == == == == == == Mutation == == == == == == ==
    vi = pop + F(:, ones(1, D)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
    [vi] = BoundaryDetection(vi,lu);

    % == == == == == == == Crossover == == == == == == ==
    mask = rand(popuSize, D) > CR(:, ones(1, D));                      % mask is used to indicate which elements of ui comes from the parent
    rows = (1 : popuSize)'; cols = floor(rand(popuSize, 1) * D)+1;      % choose one position where the element of ui doesn't come from the parent
    jrand = sub2ind([popuSize D], rows, cols); mask(jrand) = false;
    ui = vi;
    ui(mask) = pop(mask);
    %             valOffspring = benchmark_func(ui, problem, o, A, M, a, alpha, b);

    popu = ui;
%     par=0;

    parfor k=1:popuSize % evaluating the layouts

    [ParrayW, ParrayBuoyW, qW] = transformation(Max_Buoy_Num*2, popu(k,:), siteOpts, buoy,par);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%初始化不能用00000000（zeros）

    parent(k).qW               = qW;
    parent(k).ParrayW          = ParrayW;
    parent(k).ParrayBuoyW      = ParrayBuoyW;

    end            

    % == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
    % I == 1: the parent is better; I == 2: the offspring is better
    [firstpopPW, I] = max([firstpopPW; parent(:).ParrayW], [], 1);
    firstpopPW1=firstpopPW';
    popold = pop;

    archive = updateArchive(archive, popold(I == 1, :), firstpopPW1(I == 1));

    popold(I == 2, :) = ui(I == 2, :);

    goodCR = CR(I == 2);
    goodF = F(I == 2);

    k_circle = k_circle + 1;

    [valBest, indBest] = sort(firstpopPW, 'descend');

    if I == 1
        disp(['Best layout=',mat2str(round(pop(indBest(1),:),3))])
        disp(['Iteration ' num2str(iter) ': Best total power output = ' num2str(valBest(1))]);
        fordisptemplo(iter,:) = round(pop(indBest(1),:),3);
        fordisptemp(iter) = valBest(1);
    else
        disp(['Best layout=',mat2str(round(popu(indBest(1),:),3))])
        disp(['Iteration ' num2str(iter) ': Best total power output = ' num2str(valBest(1))]);
        fordisptemplo(iter,:) = round(popu(indBest(1),:),3);
        fordisptemp(iter) = valBest(1);
    end
    



end

t = t + 1;
end
end
