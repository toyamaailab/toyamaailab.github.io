%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%     Wave Energy Converters position optimization by Improvement CJADE


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clc
clear all;
close all;

slCharacterEncoding('US-ASCII')

rand()% creating random number generator based on the current time
id                  = 1;
WaveModel           = 2;        % 1= Perth, 2=Adelaide, 3=Tasmania, 4=Sydeny
Safe_Distance       = 50;        % the minimum distance between buoys
Max_Buoy_Num        = 4;
par                 = 1;     % 1 = parallel on; 0 = parallel off
% Run the position optimization method 
WEC_CJADEUPDATE_S(WaveModel,Max_Buoy_Num,Safe_Distance,id,par)

