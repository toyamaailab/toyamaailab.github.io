clc
clear
Strategy = 1;
algorithmDir = 'CGPSO_s1';
run('main.m')

clc
clear
Strategy = 2;
algorithmDir = 'CGPSO_s2';
run('main.m')

clc
clear
Strategy = 3;
algorithmDir = 'CGPSO_s3';
run('main.m')

clc
clear
Strategy = 4;
algorithmDir = 'CGPSO_s4';
run('main.m')